from flask import Flask, render_template, request, redirect,session, url_for, flash, abort, make_response
import mysql.connector
from mysql.connector import Error
from werkzeug.utils import secure_filename
import json
import os
import re
from flask import jsonify,send_file
import time
from mysql.connector import IntegrityError
import pandas as pd
from io import BytesIO
from datetime import datetime, timedelta



app = Flask(__name__)
app.secret_key = 'abdkfnsldladhlaihdkbck13445644t'  # Replace with a secure key

app.config['UPLOAD_FOLDER'] = r'C:\Users\saran\OneDrive\Desktop\new 2\static\uploads'


def get_db_connection():
    """Establish a new database connection."""
    return mysql.connector.connect(
        user='root',
        password='1708',
        host='localhost',
        database='staff_details'
    )

DEFAULT_PASSWORD = 'Mcc@123'
EMAIL_PATTERN = r'^[a-zA-Z0-9._%+-]+@mcc\.edu\.in$'

def validate_email(email):
    return re.match(EMAIL_PATTERN, email) is not None


# Define a rate limit (e.g., 1 visit count increase per 5 minutes per IP)
RATE_LIMIT_PERIOD = timedelta(minutes=1)


@app.route('/view_details/<int:id>')
def view_details(id):
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Fetch color settings
        cursor.execute("SELECT header_color, sidebar_color FROM color_settings WHERE id = 1")
        color_settings = cursor.fetchone()

        # Fetch details of the profile
        query = "SELECT * FROM details WHERE id = %s"
        cursor.execute(query, (id,))
        details = cursor.fetchone()

        if details:
            # Safely load JSON fields
            details['research_ids'] = json.loads(details.get('research_ids', '[]'))
            details['education'] = json.loads(details.get('education', '[]'))
            details['funding'] = json.loads(details.get('funding', '[]'))
            details['publications'] = json.loads(details.get('publications', '[]'))

            # Process other fields
            details['career_highlights'] = [item.strip() for item in details.get('career_highlights', '').split('\n') if item.strip()]
            details['research_career'] = [item.strip() for item in details.get('research_career', '').split('\n') if item.strip()]
            details['research_areas'] = [item.strip() for item in details.get('research_areas', '').split('\n') if item.strip()]
            details['collab'] = [item.strip() for item in details.get('collab', '').split('\n') if item.strip()]

            # Replace None values with empty strings
            for key in details:
                if details[key] is None:
                    details[key] = ''

            details['website'] = details.get('website', '')

            # Get visitor's IP address
            visitor_ip = request.remote_addr
            now = datetime.now()

            # Check the visit log for the user and IP
            cursor.execute("""
                SELECT timestamp FROM visit_logs
                WHERE user_id = %s AND ip_address = %s
                ORDER BY timestamp DESC
                LIMIT 1
            """, (id, visitor_ip))
            last_visit = cursor.fetchone()

            # If last visit is within the rate limit period, do not increment the count
            if last_visit and now - last_visit['timestamp'] < RATE_LIMIT_PERIOD:
                cursor.close()
                connection.close()
                return render_template('view_details.html', details=details, colors=color_settings)

            # Increment the visit count and update visit log
            cursor.execute("UPDATE details SET visit_count = visit_count + 1 WHERE id = %s", (id,))
            cursor.execute("""
                INSERT INTO visit_logs (user_id, ip_address, timestamp)
                VALUES (%s, %s, %s)
            """, (id, visitor_ip, now))
            connection.commit()

        cursor.close()
        connection.close()

        if details:
            return render_template('view_details.html', details=details, colors=color_settings)
        else:
            flash('No details found for this ID.', 'warning')
            return redirect(url_for('dashboard'))
    except Exception as e:
        print(f"Error fetching data: {e}")
        flash('An error occurred while fetching data from the database.', 'danger')
        return redirect(url_for('dashboard'))




@app.route('/index')
def index():
    try:
        # Establish a database connection
        connection = get_db_connection()
        cur = connection.cursor()

        # Fetch color settings
        cur.execute("SELECT header_color, sidebar_color FROM color_settings WHERE id = 1")
        color_settings = cur.fetchone()

        # Fetch funding, research_areas, and publications columns from all staff
        cur.execute("SELECT id, name, department, funding, research_areas, publications, visit_count FROM details")
        result = cur.fetchall()

        # Initialize counts and data lists
        total_funding_count = 0
        total_publications_count = 0
        all_funding = []
        all_research_areas = []

        # Process each row to count and collect funding and publication entries
        for row in result:
            staff_id, name, department, funding, research_areas, publications, visit_count = row

            # Handle funding: Extract items between double quotes and count them
            if funding:
                funding_list = re.findall(r'\"(.*?)\"', funding)  # Extract text between quotes
                total_funding_count += len(funding_list)
                for fund in funding_list:
                    all_funding.append({
                        "name": name,
                        "department": department,
                        "funding": fund
                    })

            # Handle research_areas: Split by newlines and strip
            if research_areas:
                research_areas_list = [item.strip() for item in research_areas.split('\n') if item.strip()]
                for area in research_areas_list:
                    all_research_areas.append({
                        "name": name,
                        "department": department,
                        "research_area": area
                    })

            # Handle publications: Parse JSON-like string and count publication objects
            if publications:
                try:
                    publications_list = json.loads(publications)  # Parse the JSON data
                    total_publications_count += len(publications_list)
                except json.JSONDecodeError:
                    pass  # Handle any malformed JSON

        # Sort funding and research areas alphabetically
        all_funding = sorted(all_funding, key=lambda x: x["funding"].lower())
        all_research_areas = sorted(all_research_areas, key=lambda x: x["research_area"].lower())

        # Fetch top 5 profiles by visit count
        cur.execute("""
            SELECT id, name, visit_count
            FROM details
            ORDER BY visit_count DESC
            LIMIT 5
        """)
        top_visits = cur.fetchall()

        cur.close()
        connection.close()

        # Render the index template with counts, data lists, color settings, and visit counts
        return render_template(
            'index.html',
            funding_count=total_funding_count,
            publications_count=total_publications_count,
            all_funding=all_funding,
            all_research_areas=all_research_areas,
            header_color=color_settings[0],
            sidebar_color=color_settings[1],
            top_visits=top_visits
        )
    
    except Exception as e:
        # Handle exceptions (logging, error messages, etc.)
        print(f"An error occurred: {e}")
        return render_template('error.html', error_message="An error occurred while processing your request.")


@app.route('/save_colors', methods=['POST'])
def save_colors():
    header_color = request.form.get('header_color')
    sidebar_color = request.form.get('sidebar_color')
    
    connection = get_db_connection()
    cur = connection.cursor()
    
    # Assuming you have a single row in the `color_settings` table with `id=1`
    cur.execute("""
        UPDATE color_settings 
        SET header_color = %s, sidebar_color = %s 
        WHERE id = 1
    """, (header_color, sidebar_color))
    
    connection.commit()
    cur.close()
    connection.close()
    
    flash('Colour changed succesfull', 'success')
    return redirect(url_for('index'))
   

@app.route('/tables')
def tables():
    # Fetch all staff details from the database
    connection = get_db_connection()
    cur = connection.cursor()
    cur.execute("SELECT * FROM details")
    staff_details = cur.fetchall()
    cur.close()
    connection.close()
    
    return render_template('tables.html', staff_details=staff_details)


@app.route('/staff', methods=['GET'])
def staff():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM staff")
    staff_details = cursor.fetchall()

    # Filter out admins
    non_admin_staff = [staff for staff in staff_details if staff['role'] != 'admin']

    # Calculate counts
    email_count = len(non_admin_staff)
    password_changed_count = sum(1 for staff in non_admin_staff if staff['password_changed'] == 1)
    profile_completed_count = sum(1 for staff in non_admin_staff if staff['profile_completed'] == 1)
    
    cursor.close()
    conn.close()
    
    return render_template('staff.html', 
                           staff_details=staff_details, 
                           email_count=email_count,
                           password_changed_count=password_changed_count,
                           profile_completed_count=profile_completed_count)


@app.route('/delete_details/<int:id>', methods=['POST'])
def delete_details(id):
    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # Get the email of the details to delete
        cursor.execute("SELECT email FROM details WHERE id = %s", (id,))
        detail = cursor.fetchone()
        
        if detail:
            email = detail[0]  # Access tuple element by index

            cursor.execute("DELETE FROM visit_logs WHERE user_id = (SELECT id FROM details WHERE email = %s)", (email,))
            
            # Delete the details record
            cursor.execute("DELETE FROM details WHERE id = %s", (id,))

            # Delete corresponding staff record
            cursor.execute("DELETE FROM staff WHERE email = %s", (email,))

            connection.commit()
            flash('Staff details and credentials deleted successfully.', 'success')
        else:
            flash('Details not found.', 'danger')

    except Error as e:
        print(f"Database error: {e}")
        flash('An error occurred while deleting data from the database.', 'danger')
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

    return redirect(url_for('tables'))

@app.route('/delete_staff/<int:id>', methods=['POST'])
def delete_staff(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Get the email of the staff to delete
    cursor.execute("SELECT email FROM staff WHERE id = %s", (id,))
    staff = cursor.fetchone()
    
    if staff:
        email = staff[0]  # Access tuple element by index
        cursor.execute("DELETE FROM visit_logs WHERE user_id = (SELECT id FROM details WHERE email = %s)", (email,))
        
        # Delete the staff record
        cursor.execute("DELETE FROM staff WHERE id = %s", (id,))

        # Delete corresponding details record
        cursor.execute("DELETE FROM details WHERE email = %s", (email,))

        conn.commit()
        flash('Staff credentials and details deleted successfully.', 'success')
    else:
        flash('Staff not found.', 'danger')

    cursor.close()
    conn.close()
    return redirect(url_for('staff'))


@app.route('/add_staff', methods=['POST'])
def add_staff():
    emails = request.form.get('staffEmails')
    if emails:
        email_list = [email.strip() for email in emails.split('\n') if email.strip()]
        conn = get_db_connection()
        cursor = conn.cursor()
        success_count = 0
        error_count = 0
        error_emails = []

        for email in email_list:
            try:
                cursor.execute(
                    "INSERT INTO staff (email, password, password_changed, profile_completed, role) VALUES (%s, %s, %s, %s, %s)",
                    (email, 'Mcc@123', 0, 0, 'staff')
                )
                success_count += 1
            except mysql.connector.Error as e:
                if e.errno == mysql.connector.errorcode.ER_DUP_ENTRY:
                    error_emails.append(email)  # Collect duplicate emails
                    error_count += 1
                else:
                    # Handle other database errors
                    print(f"Database error: {e}")
                    flash('An error occurred while adding staff members. Please try again.', 'danger')
                    conn.rollback()
                    cursor.close()
                    conn.close()
                    return redirect(url_for('staff'))

        conn.commit()
        cursor.close()
        conn.close()

        if success_count > 0:
            flash(f'{success_count} staff member(s) added successfully!', 'success')
        if error_count > 0:
            flash(f'{error_count} email address(es) already exist: {", ".join(error_emails)}', 'warning')

    else:
        flash('No email addresses provided!', 'danger')

    return redirect(url_for('staff'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            
            return redirect(url_for('login'))

        if not validate_email(email):
            flash('Invalid email format. Please use an @mcc.edu.in address.', 'error')
            return redirect(url_for('login'))

        try:
            connection = get_db_connection()
            cursor = connection.cursor()

            # Fetch user details from the users table including the role
            cursor.execute("SELECT password, password_changed, profile_completed, role FROM staff WHERE email=%s", (email,))
            user = cursor.fetchone()

            if user:
                stored_password, password_changed, profile_completed, role = user

                # Verify the password
                if stored_password == password:  # You should use hashed passwords in a real scenario
                    if role == 'admin':
                        # If user is admin, skip the additional checks
                        session['user_type'] = 'admin'
                        return redirect(url_for('index'))  # Redirect to the admin index page
                    else:
                        # If user is staff, perform additional checks
                        if stored_password == DEFAULT_PASSWORD:
                            if password == DEFAULT_PASSWORD:
                                # Redirect to reset_password with the email parameter
                                return redirect(url_for('reset_password', email=email))
                            else:
                                flash('Invalid credentials', 'error')
                                return redirect(url_for('login'))
                        else:
                            if password_changed == 0:
                                flash('Password has not been set up yet', 'error')
                                return redirect(url_for('login'))
                            elif profile_completed == 0:
                                # Redirect to the form page if profile is not completed
                                return redirect(url_for('submit_form',email=email))
                            else:
                                session['user_type'] = 'user'
                                # Redirect to the profile page if profile is completed
                                return redirect(url_for('profile', email=email))
                else:
                    flash('Invalid credentials', 'error')
                    return redirect(url_for('login'))
            else:
                flash('User does not exist', 'error')
                return redirect(url_for('login'))

        except Error as e:
            print(f"Database error: {e}")
            flash('An error occurred while processing your request.', 'error')
            return redirect(url_for('login'))

        finally:
            if connection:
                cursor.close()
                connection.close()

    # Render the login page with flash messages if there are any
    return render_template('login.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    email = request.args.get('email')

    if not email:
        flash('Invalid request. Email is required.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        if not new_password or not confirm_password:
            flash('Password cannot be empty.', 'error')
        elif new_password != confirm_password:
            flash('Passwords do not match.', 'error')
        elif len(new_password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
        else:
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute(
                "UPDATE staff SET password=%s, password_changed=TRUE WHERE email=%s",
                (new_password, email)  # Store plain text password
            )
            connection.commit()
            flash('Password has been successfully reset.', 'success')
            return redirect(url_for('login'))

    # Render the template with an empty message if no errors
    return render_template('reset_password.html', email=email, message='')

@app.route('/submit_form', methods=['GET', 'POST'])
def submit_form():
    email = request.args.get('email')
    if request.method == 'POST':
        # Retrieve personal information (existing code)
        name = request.form.get('name', '').strip()
        Title = request.form.get('Title', '').strip()
        institution = request.form.get('institution', '').strip()
        
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()
        website = request.form.get('website', '').strip()
        department = request.form.get('department', '').strip()
        research_areas = [line.strip() for line in request.form.get('research_areas', '').split('\n') if line.strip()]

        # Handle profile picture upload (existing code)
        default_picture_filename = 'default.webp'
        profile_picture = request.files.get('profile_picture')
        profile_picture_filename = default_picture_filename

        if profile_picture and profile_picture.filename != '':
            file_extension = os.path.splitext(profile_picture.filename)[1]
            timestamp = int(time.time())
            profile_picture_filename = f"{secure_filename(name)}_{timestamp}{file_extension}"
            profile_picture_path = os.path.join(app.config['UPLOAD_FOLDER'], profile_picture_filename)
            profile_picture.save(profile_picture_path)

        print(f"Profile picture filename: {profile_picture_filename}")

        # Retrieve dynamic research IDs (existing code)
        research_ids = []
        for i in range(50):
            title = request.form.get(f'research_ids_title_{i+1}', '').strip()
            link = request.form.get(f'research_ids_id_{i+1}', '').strip()
            if title or link:
                research_ids.append({"title": title, "id": link})

        # Retrieve dynamic education fields (existing code)
        education = []
        for i in range(50):
            degree = request.form.get(f'education_degree_{i+1}', '').strip()
            college = request.form.get(f'education_college_{i+1}', '').strip()
            duration = request.form.get(f'education_duration_{i+1}', '').strip()
            if degree or college or duration:
                education.append({"degree": degree, "college": college, "duration": duration})

        # Retrieve dynamic funding fields (existing code)
        funding_items = [request.form.get(f'funding_{i+1}', '').strip() for i in range(10) if request.form.get(f'funding_{i+1}', '').strip()]

        # Retrieve dynamic publications fields (existing code)
        publications = []
        for i in range(50):
            pub_title = request.form.get(f'publications_title_{i+1}', '').strip()
            pub_link = request.form.get(f'publications_link_{i+1}', '').strip()
            if pub_title or pub_link:
                publications.append({"title": pub_title, "link": pub_link})

        # Retrieve other sections (existing code)
        career_highlights = [line.strip() for line in request.form.get('career_highlights', '').split('\n') if line.strip()]
        research_career = [line.strip() for line in request.form.get('research_career', '').split('\n') if line.strip()]
        collab = [line.strip() for line in request.form.get('collab', '').split('\n') if line.strip()]

        # Updated PhD Scholars Section
        phd_scholars_produced = request.form.get('phd_scholars_produced', '0').strip()  # Default to '0' if empty
        phd_scholars_registered = request.form.get('phd_scholars_registered', '0').strip()  # Default to '0' if empty

        # Ensure the values are valid integers or default to 0
        phd_scholars_produced = int(phd_scholars_produced) if phd_scholars_produced.isdigit() else 0
        phd_scholars_registered = int(phd_scholars_registered) if phd_scholars_registered.isdigit() else 0

        # PhD Scholars Details
        phd_scholars = []
        for i in range(50):  # Assuming max 50 PhD scholars
            scholar_name = request.form.get(f'phd_name_{i}', '').strip()
            scholar_topic = request.form.get(f'phd_topic_{i}', '').strip()
            scholar_status = request.form.get(f'phd_status_{i}', '').strip()
            scholar_years = request.form.get(f'phd_years_{i}', '').strip()
            if scholar_name or scholar_topic or scholar_status or scholar_years:
                phd_scholars.append({
                    "name": scholar_name,
                    "topic": scholar_topic,
                    "status": scholar_status,
                    "years_of_completion": scholar_years
                })

        # Convert lists to JSON strings (existing code with added PhD scholars fields)
        research_ids_json = json.dumps(research_ids)
        education_json = json.dumps(education)
        funding_json = json.dumps(funding_items)
        publications_json = json.dumps(publications)
        phd_scholars_json = json.dumps(phd_scholars)

        try:
            connection = get_db_connection()
            cursor = connection.cursor()
            
            # Insert Query (updated to include new PhD scholars fields)
            insert_query = """
            INSERT INTO details (name, Title, institution, email, phone, address, website, profile_picture, department, 
                                 research_areas, research_ids, education, funding, publications, career_highlights, 
                                 research_career, collab, phd_scholars_produced, phd_scholars_registered, phd_scholars)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            print(f"Insert Query: {insert_query}")
            print(f"Parameters: {(
                name, Title, institution, email, phone, address, website, profile_picture_filename, department,
                '\n'.join(research_areas), research_ids_json, education_json, funding_json, publications_json,
                '\n'.join(career_highlights), '\n'.join(research_career), '\n'.join(collab),
                phd_scholars_produced, phd_scholars_registered, phd_scholars_json
            )}")

            # Execute Insert Query
            cursor.execute(insert_query, (
                name, Title, institution, email, phone, address, website, profile_picture_filename, department,
                '\n'.join(research_areas), research_ids_json, education_json, funding_json, publications_json,
                '\n'.join(career_highlights), '\n'.join(research_career), '\n'.join(collab),
                phd_scholars_produced, phd_scholars_registered, phd_scholars_json
            ))
            connection.commit()

            # Update profile_completed column in staff table (existing code)
            update_query = """
            UPDATE staff SET profile_completed = 1 WHERE email = %s
            """
            cursor.execute(update_query, (email,))
            connection.commit()

            cursor.close()
            connection.close()

            flash('Form submitted successfully!', 'success')
            return redirect(url_for('profile'))  # Redirect after successful POST
        except Exception as e:
            print(f"Error: {e}")
            flash('An error occurred while submitting the form. Please try again.', 'error')
            return redirect(url_for('profile'))

    return render_template('form.html', email=email)


    
@app.route('/profile')
def profile():
    email = request.args.get('email')  # Get the email parameter

    if not email:
        return redirect(url_for('login', message='Email is required to view the profile.'))

    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Query to get user details
        query = """
        SELECT
            id, name, Title, institution, email, phone, address, website,
            profile_picture, department, research_areas, research_ids, education,
            funding, publications, career_highlights, research_career
        FROM details
        WHERE email = %s
        """
        cursor.execute(query, (email,))
        user_data = cursor.fetchone()

        if not user_data:
            abort(404, description="User not found")


        # Convert JSON strings back to lists
        user_data['research_areas'] = user_data['research_areas'].split('\n') if user_data['research_areas'] else []
        user_data['research_ids'] = json.loads(user_data['research_ids']) if user_data['research_ids'] else []
        user_data['education'] = json.loads(user_data['education']) if user_data['education'] else []
        user_data['funding'] = json.loads(user_data['funding']) if user_data['funding'] else []
        user_data['publications'] = json.loads(user_data['publications']) if user_data['publications'] else []
        user_data['career_highlights'] = user_data['career_highlights'].split('\n') if user_data['career_highlights'] else []
        user_data['research_career'] = user_data['research_career'].split('\n') if user_data['research_career'] else []

        cursor.close()
        connection.close()
        

        return render_template('profile.html', user=user_data)

    except Error as e:
        print(f"Error: {e}")
        abort(500, description="An error occurred while retrieving user data.")




@app.route('/', methods=['GET', 'POST'])
@app.route('/dashboard', methods=['GET']) 
def dashboard():
    search_query = request.args.get('search', '').strip()
    selected_department = request.args.get('department', '').strip()

    staff_details = []
    departments_with_staff = {}

    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Fetch all departments and their staff details
        query_departments = "SELECT DISTINCT department FROM details"
        cursor.execute(query_departments)
        departments = cursor.fetchall()

        for department in departments:
            dept_name = department['department']
            query_staff = "SELECT id, name FROM details WHERE department = %s"
            cursor.execute(query_staff, (dept_name,))
            staff_in_dept = cursor.fetchall()
            departments_with_staff[dept_name] = staff_in_dept

        if selected_department:
            query = """
            SELECT id, profile_picture, name, Title, institution, department, email, phone, address, website, 
                   research_areas, research_ids, education, funding, publications, career_highlights, research_career, collab
            FROM details
            WHERE department = %s
            ORDER BY id DESC
            """
            cursor.execute(query, (selected_department,))
        else:
            # Split the search query by commas and filter out empty terms
            search_terms = [term.strip().lower() for term in search_query.split(',') if term.strip()]
            
            if search_terms:
                search_conditions = []
                search_params = []

                # Build the dynamic query with multiple LIKE conditions
                for term in search_terms:
                    search_conditions.append("""
                    LOWER(name) LIKE %s OR LOWER(Title) LIKE %s OR LOWER(department) LIKE %s OR LOWER(institution) LIKE %s
                    OR LOWER(email) LIKE %s OR LOWER(phone) LIKE %s OR LOWER(address) LIKE %s OR LOWER(website) LIKE %s
                    OR LOWER(research_areas) LIKE %s OR LOWER(research_ids) LIKE %s OR LOWER(education) LIKE %s OR LOWER(funding) LIKE %s
                    OR LOWER(publications) LIKE %s OR LOWER(career_highlights) LIKE %s OR LOWER(research_career) LIKE %s OR LOWER(collab) LIKE %s
                    """)
                    # Add each search term to the parameters (for all fields)
                    search_params.extend([f"%{term}%"] * 16)

                # Combine all conditions
                query = f"""
                SELECT id, profile_picture, name, Title, institution, department, email, phone, address, website, 
                       research_areas, research_ids, education, funding, publications, career_highlights, research_career, collab
                FROM details
                WHERE {' OR '.join(search_conditions)}
                ORDER BY id DESC
                """
                cursor.execute(query, search_params)

                staff_details = cursor.fetchall()

                for detail in staff_details:
                    # For each detail, check if any of the search terms match
                    matched_texts = []
                    for term in search_terms:
                        matched_text = extract_matched_text(detail, term)
                        if matched_text:
                            matched_texts.append(matched_text)
                    detail['matched_text'] = ', '.join(matched_texts) if matched_texts else ''

        cursor.close()
        connection.close()

    except Error as e:
        print(f"Database error: {e}")
        flash('An error occurred while processing your request.', 'danger')

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        # If the request is AJAX, return JSON
        return jsonify(staff_details)
    else:
        # Otherwise, render the dashboard template
        return render_template('dashboard.html', 
                               staff_details=staff_details,
                               departments_with_staff=departments_with_staff,
                               search_query=search_query)


    
def clean_json_text(text):
    """Remove JSON-like symbols and special characters from the text."""
    # Remove JSON brackets, quotes, and extra whitespace
    cleaned_text = re.sub(r'[\[\]\"\'\s]+', ' ', text).strip()
    # Remove any URLs from the text
    cleaned_text = re.sub(r'http[s]?://\S+', '', cleaned_text).strip()
    return cleaned_text

def extract_matched_text(detail, search_query):
    """
    Extract the first matching word from the given detail dictionary based on search_query.
    If a match is found, return the matching text; otherwise, return an empty string.
    """
    search_query = search_query.lower()

    # Function to find and return the closest match in a list of words
    def find_closest_match(text, query):
        words = re.findall(r'\b\w+\b', text)  # Tokenize the text into words
        for word in words:
            if query in word.lower():
                return word  # Return the word containing the search query
        return None

    # Check if the search query matches the name field
    if 'name' in detail and search_query in detail['name'].lower():
        return find_closest_match(detail['name'], search_query)

    # Check other fields for a match
    for key, value in detail.items():
        if isinstance(value, str):
            # Clean the text to remove special characters
            value = clean_json_text(value)
            
            # Check if the value is JSON-encoded
            try:
                json_value = json.loads(value)
                if isinstance(json_value, list):
                    # Handle JSON list
                    for item in json_value:
                        if isinstance(item, dict):
                            item_text = ' '.join(item.values())
                            closest_match = find_closest_match(item_text, search_query)
                            if closest_match:
                                return closest_match
                        elif isinstance(item, str):
                            closest_match = find_closest_match(item, search_query)
                            if closest_match:
                                return closest_match
                elif isinstance(json_value, dict):
                    # Handle JSON dict
                    item_text = ' '.join(json_value.values())
                    closest_match = find_closest_match(item_text, search_query)
                    if closest_match:
                        return closest_match
                else:
                    # Handle plain text in JSON
                    closest_match = find_closest_match(value, search_query)
                    if closest_match:
                        return closest_match
            except (json.JSONDecodeError, TypeError):
                # Not a JSON-encoded string, handle as plain text
                if key in ['research_areas', 'career_highlights', 'research_career', 'collab']:
                    # Special handling for specific fields
                    items = value.split('\n')
                    for item in items:
                        closest_match = find_closest_match(item, search_query)
                        if closest_match:
                            return closest_match
                else:
                    closest_match = find_closest_match(value, search_query)
                    if closest_match:
                        return closest_match

    # If no match is found, return an empty string (not "No match found")
    return ''



@app.route('/update_profile/<email>', methods=['GET'])
def render_update_page(email):
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM details WHERE email = %s"
        
        cursor.execute(query, (email,))
        staff = cursor.fetchone()
        cursor.close()
        connection.close()
        print("Fetched staff details:", staff)

        if staff:
            # Handle JSON fields
            try:
                staff['research_ids'] = json.loads(staff['research_ids']) if staff['research_ids'] else []
                staff['education'] = json.loads(staff['education']) if staff['education'] else []
                staff['funding'] = json.loads(staff['funding']) if staff['funding'] else []
                staff['publications'] = json.loads(staff['publications']) if staff['publications'] else []
                staff['phd_scholars'] = json.loads(staff.get('phd_scholars', '[]')) if staff['phd_scholars'] else []
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {e}")

            staff['career_highlights'] = [item.strip() for item in staff['career_highlights'].split('\n') if item.strip()]
            staff['research_career'] = [item.strip() for item in staff['research_career'].split('\n') if item.strip()]
            staff['research_areas'] = [area.strip() for area in staff['research_areas'].split(',') if area.strip()]
            staff['collab'] = [area.strip() for area in staff['collab'].split(',') if area.strip()]

        return render_template('update.html', staff=staff)

    except Error as e:
        print(f"Database error: {e}")
        return redirect(url_for('profile'))


@app.route('/update_profile/<email>', methods=['POST'])
def update_profile(email):
    if request.method == 'POST':
        try:
            # Retrieve personal information from the form
            name = request.form.get('name') or None
            Title = request.form.get('Title') or None
            institution = request.form.get('institution') or None
            phone = request.form.get('phone') or None
            address = request.form.get('address') or None
            website = request.form.get('website') or None
            department = request.form.get('department') or None
            research_areas = [line.strip() for line in request.form.get('research_areas', '').split('\n') if line.strip()]

            # Retrieve career highlights and research career
            career_highlights = [line.strip() for line in request.form.get('career_highlights', '').split('\n') if line.strip()]
            research_career = [line.strip() for line in request.form.get('research_career', '').split('\n') if line.strip()]
            collab = [line.strip() for line in request.form.get('collab', '').split('\n') if line.strip()]

            # Handle profile picture file upload
            connection = get_db_connection()
            cursor = connection.cursor()

            # Retrieve the current profile picture filename from the database
            cursor.execute("SELECT profile_picture FROM details WHERE email=%s", (email,))
            result = cursor.fetchone()
            old_profile_picture_filename = result[0] if result else None
            cursor.close()

            # Handle new profile picture upload
            profile_picture = request.files.get('profile_picture')
            if profile_picture and profile_picture.filename:
                file_extension = os.path.splitext(profile_picture.filename)[1]
                timestamp = int(time.time())
                profile_picture_filename = f"{secure_filename(name)}_{timestamp}{file_extension}"
                profile_picture_path = os.path.join(app.config['UPLOAD_FOLDER'], profile_picture_filename)
                profile_picture.save(profile_picture_path)
            else:
                profile_picture_filename = old_profile_picture_filename

            # Retrieve dynamic research IDs
            research_ids = []
            for i in range(50):
                title = request.form.get(f'research_ids_title_{i+1}', '').strip()
                link = request.form.get(f'research_ids_id_{i+1}', '').strip()
                if title or link:
                    research_ids.append({"title": title, "id": link})

            # Retrieve dynamic education fields
            education = []
            for i in range(50):
                degree = request.form.get(f'education_degree_{i+1}', '').strip()
                college = request.form.get(f'education_college_{i+1}', '').strip()
                duration = request.form.get(f'education_duration_{i+1}', '').strip()
                if degree or college or duration:
                    education.append({"degree": degree, "college": college, "duration": duration})

            # Retrieve dynamic funding fields
            funding_items = [request.form.get(f'funding_{i+1}', '').strip() for i in range(10) if request.form.get(f'funding_{i+1}', '').strip()]

            # Retrieve dynamic publications fields
            publications = []
            for i in range(50):
                pub_title = request.form.get(f'publications_title_{i+1}', '').strip()
                pub_link = request.form.get(f'publications_link_{i+1}', '').strip()
                if pub_title or pub_link:
                    publications.append({"title": pub_title, "link": pub_link})

            # Retrieve PhD supervisor data
            research_supervisor = request.form.get('research_supervisor')
            phd_scholars = []
            phd_scholars_produced = None
            phd_scholars_registered = None

            if research_supervisor == 'yes':
                # Get the number of PhD scholars produced and registered
                phd_scholars_produced = request.form.get('phd_scholars_produced')
                phd_scholars_registered = request.form.get('phd_scholars_registered')

                # Loop through dynamic PhD scholar fields
                for i in range(50):
                    scholar_name = request.form.get(f'phd_name_{i}', '').strip()
                    scholar_topic = request.form.get(f'phd_topic_{i}', '').strip()
                    scholar_status = request.form.get(f'phd_status_{i}', '').strip()
                    scholar_years = request.form.get(f'phd_years_{i}', '').strip()

                    if scholar_name or scholar_topic or scholar_status or scholar_years:
                        phd_scholars.append({
                            "name": scholar_name,
                            "topic": scholar_topic,
                            "status": scholar_status,
                            "years_of_completion": scholar_years
                        })
            else:
                # If "No" is selected, PhD scholars data should be cleared
                phd_scholars_produced = None
                phd_scholars_registered = None
                phd_scholars = []

            # Convert lists to JSON strings
            research_ids_json = json.dumps(research_ids)
            education_json = json.dumps(education)
            funding_json = json.dumps(funding_items)
            publications_json = json.dumps(publications)
            phd_scholars_json = json.dumps(phd_scholars)

            # Debug information
            print("Updating with the following data:")
            print(f"Name: {name}, Title: {Title}, Institution: {institution}, Phone: {phone}")
            print(f"Address: {address}, Website: {website}, Department: {department}")
            print(f"Profile Picture Filename: {profile_picture_filename}")
            print(f"Research Areas: {research_areas}")
            print(f"Research IDs JSON: {research_ids_json}")
            print(f"Education JSON: {education_json}")
            print(f"Funding JSON: {funding_json}")
            print(f"Publications JSON: {publications_json}")
            print(f"Career Highlights: {career_highlights}")
            print(f"Research Career: {research_career}")
            print(f"Collab: {collab}")
            print(f"PhD Scholars Produced: {phd_scholars_produced}")
            print(f"PhD Scholars Registered: {phd_scholars_registered}")
            print(f"PhD Scholars JSON: {phd_scholars_json}")

            # Update database
            connection = get_db_connection()
            cursor = connection.cursor()

            update_query = """
            UPDATE details SET
                name=%s, Title=%s, institution=%s, phone=%s, address=%s, website=%s,
                profile_picture=%s, department=%s, research_areas=%s, research_ids=%s,
                education=%s, funding=%s, publications=%s, career_highlights=%s, research_career=%s, collab=%s,
                phd_scholars_produced=%s, phd_scholars_registered=%s, phd_scholars=%s
            WHERE email=%s
            """
            
            cursor.execute(update_query, (
                name, Title, institution, phone, address, website,
                profile_picture_filename, department, '\n'.join(research_areas), research_ids_json,
                education_json, funding_json, publications_json, '\n'.join(career_highlights),
                '\n'.join(research_career), '\n'.join(collab), phd_scholars_produced, phd_scholars_registered, phd_scholars_json, email
            ))

            connection.commit()
            cursor.close()
            connection.close()
            
            flash('Profile updated successfully.', 'success')

            # Redirect based on user type
            if session.get('user_type') == 'admin':
                return redirect(url_for('tables'))  # Redirect to the admin dashboard
            else:
                return redirect(url_for('profile', email=email))  # Redirect to user


        except Exception as e:
            
            
            return redirect(url_for('update_profile', email=email))


@app.route('/show_info/<int:id>')
def show_info(id):
    
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
         # Fetch color settings (Assuming there is a table named color_settings with an id of 1)
        cursor.execute("SELECT header_color, sidebar_color FROM color_settings WHERE id = 1")
        color_settings = cursor.fetchone()
        print("Color Settings:", color_settings)  # Debugging line

        # Query to get details based on ID
        query = "SELECT * FROM details WHERE id = %s"
        cursor.execute(query, (id,))
        info = cursor.fetchone()

        if info:
            # Convert JSON strings back to lists and handle possible errors
            try:
                info['research_ids'] = json.loads(info['research_ids']) if info['research_ids'] else []
            except json.JSONDecodeError as e:
                print("Error decoding research_ids:", e)
                info['research_ids'] = []

            try:
                info['education'] = json.loads(info['education']) if info['education'] else []
            except json.JSONDecodeError as e:
                print("Error decoding education:", e)
                info['education'] = []

            try:
                info['funding'] = json.loads(info['funding']) if info['funding'] else []
            except json.JSONDecodeError as e:
                print("Error decoding funding:", e)
                info['funding'] = []

            try:
                info['publications'] = json.loads(info['publications']) if info['publications'] else []
            except json.JSONDecodeError as e:
                print("Error decoding publications:", e)
                info['publications'] = []

            if info.get('career_highlights'):
                info['career_highlights'] = [item.strip() for item in info['career_highlights'].split('\n') if item.strip()]
            
            if info.get('research_career'):
                info['research_career'] = [item.strip() for item in info['research_career'].split('\n') if item.strip()]

            if info.get('research_areas'):
                info['research_areas'] = [item.strip() for item in info['research_areas'].split('\n') if item.strip()]
            
            if info.get('collab'):
                info['collab'] = [item.strip() for item in info['collab'].split('\n') if item.strip()]
            
            
            cursor.close()
            connection.close()

            return render_template('show_info.html', info=info, colors=color_settings)
        
        else:
            flash('No information found for this ID.', 'warning')
            return redirect(url_for('profile'))
    except Error as e:
        print(f"Database error: {e}")
        flash('An error occurred while fetching data from the database.', 'danger')
        return redirect(url_for('profile'))




@app.route('/logout', methods=['POST'])
def logout():
    # Flash a success message
    flash('Logout successful!', 'success')
    
    # Create a response object and set the cookie to expire
    response = make_response(redirect(url_for('dashboard')))
    response.set_cookie('email', '', expires=0)  # Clear the email cookie
    
    return response



@app.route('/export', methods=['GET'])
def export_data():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    # Get selected columns from the query string
    selected_columns = request.args.getlist('columns')
    
    if not selected_columns:
        return 'No columns selected', 400

    # Convert the list of selected columns into a comma-separated string for SQL
    columns_string = ', '.join(selected_columns)

    # Prepare the dynamic query with only selected columns
    query = f"""
    SELECT {columns_string}
    FROM details
    """

    cursor.execute(query)
    results = cursor.fetchall()

    # Process fields to format with []
    for result in results:
        if 'career_highlights' in result and result['career_highlights']:
            result['career_highlights'] = '[' + ']['.join(result['career_highlights'].split('\n')) + ']'
        if 'research_career' in result and result['research_career']:
            result['research_career'] = '[' + ']['.join(result['research_career'].split('\n')) + ']'
        if 'collab' in result and result['collab']:
            result['collab'] = '[' + ']['.join(result['collab'].split('\n')) + ']'
        if 'research_areas' in result and result['research_areas']:
            result['research_areas'] = '[' + ']['.join(result['research_areas'].split('\n')) + ']'

        # Remove JSON format and convert to []-separated values for research_ids
        if 'research_ids' in result and result['research_ids']:
            research_ids = json.loads(result['research_ids'])
            result['research_ids'] = '[' + ']['.join([f"{item['title']} {item['id']}" for item in research_ids]) + ']'

        # Remove JSON format and convert to []-separated values for funding
        if 'funding' in result and result['funding'] and result['funding'].startswith('['):
            funding = json.loads(result['funding'])
            result['funding'] = '[' + ']['.join(funding) + ']'

        # Remove JSON format and convert to []-separated values for publications
        if 'publications' in result and result['publications']:
            publications = json.loads(result['publications'])
            result['publications'] = '[' + ']['.join([f"{pub['title']} {pub['link']}" for pub in publications]) + ']'

        # Remove JSON format and convert to []-separated values for education
        if 'education' in result and result['education']:
            education = json.loads(result['education'])
            result['education'] = '[' + ']['.join([f"{edu['degree']} {edu['college']} {edu['duration']}" for edu in education]) + ']'

        # Process PhD scholars data to separate columns and wrap in []
        if 'phd_scholars' in result and result['phd_scholars']:
            phd_scholars = json.loads(result['phd_scholars'])
            formatted_scholars = []
            for scholar in phd_scholars:
                scholar_data = f"[{scholar['name']}] [{scholar['topic']}] [{scholar['status']}] [{scholar['years_of_completion']}]"
                formatted_scholars.append(scholar_data)
            result['phd_scholars'] = ' '.join(formatted_scholars)

    # Convert results to DataFrame
    df = pd.DataFrame(results)

    # Export to Excel
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False, sheet_name='Sheet1')

    output.seek(0)
    return send_file(output, as_attachment=True, download_name='Researcher_data.xlsx')

@app.route('/phd_details')
def phd_details():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    # Query to get researcher details
    query = """
    SELECT name, department, phd_scholars, phd_scholars_registered, phd_scholars_produced
    FROM details
    """
    cursor.execute(query)
    all_details = cursor.fetchall()

    # Initialize serial numbers
    researcher_serial_number = 1  # For the "PhD Scholars Count" table (by researcher)
    running_serial_number = 1  # For the "PhD Scholars Details" table (by scholar)

    # Variables to store total counts
    total_phd_scholars_registered = 0
    total_phd_scholars_produced = 0

    # Loop through each researcher
    for detail in all_details:
        # Ensure values are integers, default to 0 if None
        phd_scholars_registered = detail['phd_scholars_registered'] or 0
        phd_scholars_produced = detail['phd_scholars_produced'] or 0

        # Assign serial number for the researcher (PhD Scholars Count)
        detail['serial_number'] = researcher_serial_number
        researcher_serial_number += 1

        # Add to total counts
        total_phd_scholars_registered += phd_scholars_registered
        total_phd_scholars_produced += phd_scholars_produced

        # Handle the scholar's details
        if detail['phd_scholars']:
            detail['phd_scholars'] = json.loads(detail['phd_scholars'])
        else:
            detail['phd_scholars'] = []

        # Loop through each scholar and assign the running serial number
        for scholar in detail['phd_scholars']:
            scholar['serial_number'] = running_serial_number
            running_serial_number += 1

    # Render the template and pass the total counts
    return render_template('phd_details.html',
                           all_details=all_details,
                           total_phd_scholars_registered=total_phd_scholars_registered,
                           total_phd_scholars_produced=total_phd_scholars_produced)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
